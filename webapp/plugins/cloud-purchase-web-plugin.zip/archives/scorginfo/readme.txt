供电公司档案管理的页面
list.jsp  : 供电公司列表页面
power-org-add.jsp	:	list页面点击新增档案的弹出页面，为供电公司的新增页面
power-org-edit.jsp	:	list页面点击某行后点击修改档案的弹出页面，为供电公司的修改页面


		